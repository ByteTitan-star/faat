# OOD-ABC 48h 网格 — 自动状态报告（watchdog 每 5 分钟更新）

更新时间: 2026-09-12 08:57:44　|　分支: ood-calibration@main　|　参照锚点: FAAT v4 — CIFAR-10 93.6 / GTSRB(l2=3.5) 82.7

| run | 状态 | epoch | ASR(末值) | ASR(末20均) | BA(末值) | BA(末20均) |
|---|---|---|---|---|---|---|
| oodabc_cifar10_a_seed1 | DONE ✅已备份 | 299 | 0.9083 | 0.8883 | 0.9483 | 0.9468 |
| oodabc_cifar10_b_seed1 | DONE ✅已备份 | 299 | 0.9683 | 0.9428 | 0.9433 | 0.9446 |
| oodabc_cifar10_c_seed1 | DONE ✅已备份 | 299 | 0.7182 | 0.7013 | 0.9473 | 0.9471 |
| oodabc_cifar10_cur_seed1 | DONE ✅已备份 | 299 | 0.9289 | 0.9289 | 0.9448 | 0.9452 |
| oodabc_cifar10_a_seed2 | DONE ✅已备份 | 299 | 0.8402 | 0.8081 | 0.9503 | 0.9493 |
| oodabc_cifar10_c_seed2 | DONE ✅已备份 | 299 | 0.8641 | 0.8261 | 0.9485 | 0.9482 |
| oodabc_gtsrb_a_seed1 | DONE ✅已备份 | 299 | 0.5050 | 0.4946 | 0.9992 | 0.9992 |
| oodabc_gtsrb_b_seed1 | DONE ✅已备份 | 299 | 0.6615 | 0.6576 | 0.9990 | 0.9987 |
| oodabc_gtsrb_c_seed1 | DONE ✅已备份 | 299 | 0.0359 | 0.0327 | 0.9995 | 0.9995 |
| oodabc_gtsrb_cur_seed1 | DONE ✅已备份 | 299 | 0.8479 | 0.8445 | 0.9985 | 0.9984 |
| oodabc_gtsrb_a_seed2 | DONE ✅已备份 | 299 | 0.5091 | 0.5072 | 0.9990 | 0.9990 |
| oodabc_gtsrb_c_seed2 | DONE ✅已备份 | 299 | 0.0398 | 0.0402 | 0.9995 | 0.9995 |

**Go/No-Go 速查**（同 L2 budget 下比 ASR，BA 不得明显跌；GTSRB 是生死场）：
- c vs a：校准项带来增益？　- c vs b：增益来自"校准"而非"多了数据"？（c≈b = NO-GO）
- 全部完成且某臂存活 → 补 seed2/3；只在 CIFAR-10 有效 → NO-GO。

日志: `results_ood/oodabc_*/output_1.log`　启动器: `results_ood/_abc_*_gpu*.log`　备份: `/media/hd0/wangxin/backup/ood_abc_20260911`
